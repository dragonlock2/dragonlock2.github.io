/*
 * AccelStepper.h
 *
 * Created: 5/7/2020 11:18:45 PM
 *  Author: Matthew Tran
 */ 

#ifndef ACCELSTEPPER_H_
#define ACCELSTEPPER_H_

#include "MyUtils.h"

#define STEPS_PER_MM 5 // 200 steps/rev / 40 mm/rev

#define STEP_REST 10 // should rest for this long when switching directions, matters at high accel
#define HOME_SPEED 200 // all mm/s, mm^2/s
#define MIN_VELOCITY 90 // below this it sounds crap
#define MAX_VELOCITY 900 // can go higher, but loses more steps
#define MIN_ACCEL 30 // below this can't even accel to max speed in time
#define MAX_ACCEL 7000 // can go higher, but doesn't really matter
inline float mmToSteps(float mm) { return STEPS_PER_MM * mm; }
inline uint16_t velocToDelay(float v) { return 1.0e6 / STEPS_PER_MM / v; }

static inline void stepEnable() { drv_enable_set_level(0); }
static inline void stepDisable() { drv_enable_set_level(1); }
static inline void setDirLeft() { drv_dir_set_level(1); }
static inline void setDirRight() { drv_dir_set_level(0); }
static inline bool getDir() { return drv_dir_get_level(); } // 1: left, 0: right
void step(uint16_t delay);
void move(uint16_t steps, float veloc, float accel); // mm/s, mm^2/s

#endif /* ACCELSTEPPER_H_ */
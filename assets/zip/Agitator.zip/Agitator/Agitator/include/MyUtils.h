/*
 * myUtils.h
 *
 * Created: 5/7/2020 10:34:15 PM
 *  Author: Matthew Tran
 */ 

#ifndef MYUTILS_H_
#define MYUTILS_H_

#include <atmel_start.h>
#include <util/delay.h>
#include <stdio.h>

typedef enum {HOME, PT1, PT2, VELOC, ACCEL, RUN} State;
volatile State state;

#define DEBOUNCE 50 // ms

void waitForPress();
void setupPWM();
void setRGB(uint8_t r, uint8_t g, uint8_t b);
void delay_us(uint16_t delay); // a bit off
uint16_t getVoltage(); // mV

#endif /* MYUTILS_H_ */
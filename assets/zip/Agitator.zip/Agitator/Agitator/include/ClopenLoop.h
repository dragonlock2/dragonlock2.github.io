/*
 * ClopenLoop.h
 *
 * Created: 5/8/2020 12:44:03 AM
 *  Author: Matthew Tran
 */ 


#ifndef CLOPENLOOP_H_
#define CLOPENLOOP_H_

#include "MyUtils.h"
#include "AccelStepper.h"

#define ENCODER_TICK_PER_MM 1

volatile int16_t encPos, encMax;

void home();
uint16_t seek(int16_t pos); // moves to pos and returns steps traveled
void alternatePos(int16_t p1, int16_t p2, float veloc, float accel); // uses clopen loop to alternate between p1 and p2

#endif /* CLOPENLOOP_H_ */
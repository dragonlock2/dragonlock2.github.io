/*
 * AccelStepper.c
 *
 * Created: 5/7/2020 11:47:22 PM
 *  Author: Matthew Tran
 */ 

#include "AccelStepper.h"

void step(uint16_t delay) {
	drv_step_set_level(1);
	_delay_us(2); // 1.9us min pulse width
	drv_step_set_level(0);
	delay_us(delay - 3); // account for computation too
}

void move(uint16_t steps, float veloc, float accel) {
	stepEnable();
	veloc = mmToSteps(veloc);
	accel = mmToSteps(accel);
	
	// Inspired by Arduino AccelStepper
	uint16_t n = 1; steps += 1;
	float c0, cn, cmin, speed;
	
	c0 = 0.676 * sqrt(2 / accel) * 1.0e6;
	cmin = 1.0e6 / veloc;
	speed = 0;
	cn = c0;
	
	while (n != steps) {
		if (!(sw_front_get_level() && (getDir() ? hall_left_get_level() : hall_right_get_level()))) {
			return;
		}
		
		step(cn - 90); // computation takes roughly hella cycles
		
		uint16_t distanceTo = steps - n;
		uint16_t stepsToStop = speed * speed / (2 * accel);
		
		if (distanceTo > stepsToStop) {
			cn = cn - 2.0 * cn / ((4.0 * n) + 1);
		} else {
			cn = cn - 2.0 * cn / ((-4.0 * stepsToStop) + 1);
		}
		if (cn < cmin) {
			cn = cmin;
			setRGB(0, 255, 0); // max speed
		} else {
			setRGB(255, 0, 0);
		}
		speed = 1.0e6 / cn;
		
		n++;
	}
}
/*
 * ClopenLoop.c
 *
 * Created: 5/8/2020 12:44:15 AM
 *  Author: Matthew Tran
 */ 

#include "ClopenLoop.h"

void home() {
	stepEnable();
	setDirLeft();
	while (hall_left_get_level()) {
		step(velocToDelay(HOME_SPEED));
	}
	_delay_ms(STEP_REST);
	encPos = 0;
	setDirRight();
	while (hall_right_get_level()) {
		step(velocToDelay(HOME_SPEED));
	}
	_delay_ms(STEP_REST);
	encMax = encPos;
}

uint16_t seek(int16_t pos) {
	stepEnable();
	encPos < pos ? setDirRight() : setDirLeft();
	uint16_t crop = 0;
	while (encPos != pos) {
		step(velocToDelay(HOME_SPEED));
		crop++;
	}
	return crop;
}

void alternatePos(int16_t p1, int16_t p2, float veloc, float accel) {
	stepEnable(); // enable even if return for some user feedback
	if (p1 == p2) {
		return;
	}
	while (sw_front_get_level()) {
		int16_t targetPos = abs(encPos - p1) < abs(encPos - p2) ? p2 : p1; // move to further point
		encPos < targetPos ? setDirRight() : setDirLeft();
		move(STEPS_PER_MM * abs(encPos - targetPos) / ENCODER_TICK_PER_MM, veloc, accel);
		_delay_ms(STEP_REST);
	}
}
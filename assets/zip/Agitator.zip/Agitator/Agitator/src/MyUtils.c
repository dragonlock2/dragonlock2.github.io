/*
 * myUtils.c
 *
 * Created: 5/7/2020 10:34:40 PM
 *  Author: Matthew Tran
 */ 

#include "MyUtils.h"

void waitForPress() {
	while (sw_front_get_level());
	_delay_ms(DEBOUNCE);
	while (!sw_front_get_level());
	_delay_ms(DEBOUNCE);
}

void setupPWM() {
	PWM_0_enable_output_ch0(); // blue
	PWM_0_enable_output_ch1(); // red
	PWM_0_enable_output_ch2(); // green
}

void setRGB(uint8_t r, uint8_t g, uint8_t b) {
	PWM_0_load_duty_cycle_ch0(b);
	PWM_0_load_duty_cycle_ch1(r);
	PWM_0_load_duty_cycle_ch2(g);
}

void delay_us(uint16_t delay) {
	while (delay--) {
		asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop");
		asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop");
		asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop");
		// subtract 5 clock cycles to account for while loop and func call
	}
}

uint16_t getVoltage() {
	// 4.34V voltage reference
	// mv = 4340 * reading / 1023 * 46k / 10k ~ 20 (lmao that approx)
	return 20 * ADC_0_get_conversion(3);
}
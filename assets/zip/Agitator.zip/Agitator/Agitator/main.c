#include "MyUtils.h"
#include "AccelStepper.h"
#include "ClopenLoop.h"

void errorVoltage();
float getMappedSlider(float min, float max);

int main(void)
{
	atmel_start_init();
	ADC_0_register_window_callback(errorVoltage);
	setupPWM();
	stepDisable();
	
	int16_t p1 = 0, p2 = 0;
	float veloc = 0, accel = 0;
	
	sw_led_set_level(1); // front led always on

	while (1) {
		switch (state) {
			case HOME:
				setRGB(255, 0, 0);
				waitForPress();
				home();
				seek(encMax/2 + 2);
				stepDisable();
				state = PT1;
				break;
			case PT1:
				setRGB(0, 255, 0);
				waitForPress();
				p1 = encPos;
				state = PT2;
				break;
			case PT2:
				setRGB(0, 0, 255);
				waitForPress();
				p2 = encPos;
				state = VELOC;
				break;
			case VELOC:
				setRGB(255, 0, 255);
				waitForPress();
				veloc = getMappedSlider(MIN_VELOCITY, MAX_VELOCITY);
				state = ACCEL;
				break;
			case ACCEL:
				setRGB(0, 255, 255);
				waitForPress();
				accel = getMappedSlider(MIN_ACCEL, MAX_ACCEL);
				state = RUN;
				break;
			case RUN:
				alternatePos(p1, p2, veloc, accel);
				setRGB(255, 255, 255);
				waitForPress(); // wait for release
				stepDisable();
				state = PT1;
				break;
		}
	}
}

void errorVoltage() {
	ADC_0_register_window_callback(NULL);
	stepDisable();
	while (1) {
		setRGB(255, 0, 0);
		_delay_ms(250);
		setRGB(0, 0, 0);
		_delay_ms(250);
	}
}

float getMappedSlider(float min, float max) {
	int16_t constrainedEncPos = encPos < 0 ? 0 : encPos > encMax ? encMax : encPos;
	return constrainedEncPos * (max - min) / encMax + min;
}
